﻿using System.Windows.Controls;

namespace Reservoom.Views
{
    /// <summary>
    /// Interaction logic for ReservationListingView.xaml
    /// </summary>
    public partial class ReservationListingView : UserControl
    {
        public ReservationListingView()
        {
            InitializeComponent();
        }
    }
}